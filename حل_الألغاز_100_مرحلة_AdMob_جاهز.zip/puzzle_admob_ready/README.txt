حل الألغاز — نسخة AdMob جاهزة للربط

هذه النسخة أزالت المكافأة التجريبية القديمة. زر «شاهد الإعلان +30» أصبح يستدعي جسر Android باسم:
Android.showRewardedAd()

بعد نجاح مشاهدة الإعلان، يجب على كود Android استدعاء JavaScript التالي داخل WebView:
window.onRewardEarned();

مهم:
- ملف index.html وحده لا يستطيع تشغيل AdMob الأصلي؛ يلزم تغليفه داخل Android WebView مع Google Mobile Ads SDK.
- أثناء الاختبار استخدم معرّف الإعلان الاختباري لـ Rewarded Ads:
  ca-app-pub-3940256099942544/5224354917
- قبل النشر استبدله بمعرّف الإعلان الخاص بك.
- معرّف تطبيق AdMob (App ID) يوضع في AndroidManifest.xml.
- يجب عدم منح العملات إلا من callback الخاص بنجاح كسب المكافأة من AdMob.

ملف AndroidBridgeExample.kt يحتوي مثال الجسر المطلوب.
