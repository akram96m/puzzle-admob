// مثال مختصر لجسر WebView + AdMob Rewarded Ads.
// أضفه إلى Activity التي تحتوي WebView بعد دمج Google Mobile Ads SDK.

import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.FullScreenContentCallback

class AdBridge(private val webView: WebView) {
    private var rewardedAd: RewardedAd? = null

    fun loadRewarded(activity: android.app.Activity) {
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            activity,
            "ca-app-pub-3940256099942544/5224354917", // TEST ID - استبدله قبل النشر
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            }
        )
    }

    @JavascriptInterface
    fun showRewarded() {
        val activity = webView.context as? android.app.Activity ?: return
        activity.runOnUiThread {
            val ad = rewardedAd
            if (ad == null) {
                loadRewarded(activity)
                return@runOnUiThread
            }

            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewarded(activity)
                }
            }

            ad.show(activity) {
                webView.post {
                    webView.evaluateJavascript("window.onRewardEarned();", null)
                }
            }
        }
    }
}

// عند إنشاء WebView:
// webView.settings.javaScriptEnabled = true
// webView.addJavascriptInterface(AdBridge(webView), "Android")
