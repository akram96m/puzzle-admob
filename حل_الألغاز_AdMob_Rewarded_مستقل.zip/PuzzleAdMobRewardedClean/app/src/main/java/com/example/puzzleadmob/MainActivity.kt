package com.example.puzzleadmob

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var rewardedAd: RewardedAd? = null

    // TEST ID for development. Replace with your real Rewarded ID only when ready to publish.
    private val rewardedId = "ca-app-pub-3940256099942544/5224354917"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)

        val root = FrameLayout(this)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        loadRewarded()
    }

    private fun loadRewarded() {
        RewardedAd.load(this, rewardedId, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(error: LoadAdError) { rewardedAd = null }
            override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad }
        })
    }

    private inner class Bridge {
        @JavascriptInterface
        fun showRewardedAd() {
            runOnUiThread {
                val ad = rewardedAd
                if (ad == null) {
                    webView.evaluateJavascript("window.onRewardUnavailable && window.onRewardUnavailable()", null)
                    loadRewarded()
                    return@runOnUiThread
                }
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        rewardedAd = null
                        loadRewarded()
                    }
                    override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                        rewardedAd = null
                        webView.evaluateJavascript("window.onRewardUnavailable && window.onRewardUnavailable()", null)
                        loadRewarded()
                    }
                }
                ad.show(this@MainActivity) {
                    webView.evaluateJavascript("window.onRewardEarned && window.onRewardEarned()", null)
                }
            }
        }
    }
}
